import * as cheerio from 'cheerio';
import { ParsedProperty, ParseResult } from './parser-types';
import { browserPool } from './browser-pool';

export async function parseCianUrl(url: string): Promise<ParseResult> {
  // Попытка 1: Быстрый HTTP запрос через Cheerio
  try {
    const response = await fetch(url, {
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
        'Cache-Control': 'no-cache',
      },
    });

    if (response.ok) {
      const html = await response.text();
      const data = extractCianFromHtml(html, url);
      if (data && data.price > 0 && data.area > 0) {
        return {
          success: true,
          data,
          method: 'cheerio',
        };
      }
    }
  } catch (e) {
    console.warn('CIAN Cheerio parse failed, falling back to Playwright:', e);
  }

  // Попытка 2: Эмуляция браузера через Playwright
  try {
    const { page, context } = await browserPool.getPage();
    try {
      await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 25000 });
      await page.waitForSelector('[data-name="OfferHeader"], [data-name="PriceInfo"], h1', {
        timeout: 10000,
      }).catch(() => {});

      const html = await page.content();
      const data = extractCianFromHtml(html, url);

      if (data && (data.price > 0 || data.address)) {
        return {
          success: true,
          data,
          method: 'playwright',
        };
      }
    } finally {
      await context.close();
    }
  } catch (e: any) {
    console.error('CIAN Playwright parse error:', e);
    const isBrowserLaunchError = e?.message?.includes('executable') || e?.message?.includes('browser') || e?.message?.includes('launch') || e?.message?.includes('Chromium');
    return {
      success: false,
      error: isBrowserLaunchError
        ? 'Не удалось загрузить данные страницы ЦИАН. Пожалуйста, введите параметры объекта вручную.'
        : `Ошибка парсинга ЦИАН: ${e.message || 'Не удалось получить данные по ссылке'}`,
    };
  }

  return {
    success: false,
    error: 'Не удалось автоматически извлечь данные с ЦИАН. Пожалуйста, введите данные вручную.',
  };
}

function extractCianFromHtml(html: string, url: string): ParsedProperty | null {
  const $ = cheerio.load(html);

  let address = '';
  let price = 0;
  let area = 0;
  let rooms = 1;
  let floor = 0;
  let totalFloors = 0;
  let renovation = 'Косметический';
  let buildingMaterial = 'Монолит';
  let yearBuilt = 2021;
  let photo = '';
  let viewsTotal = 0;
  let viewsToday = 0;

  // 1. Поиск `window._cianConfig` и `initialState` в скриптах
  const scripts = $('script').toArray();
  for (const script of scripts) {
    const content = $(script).html() || '';
    if (
      content.includes('_cianConfig') ||
      content.includes('offerData') ||
      content.includes('initialState') ||
      content.includes('bargainTerms')
    ) {
      try {
        const match =
          content.match(/window\._cianConfig\s*=\s*({[\s\S]*?});/) ||
          content.match(/initialState\s*=\s*({[\s\S]*?});/) ||
          content.match(/offerData\s*=\s*({[\s\S]*?});/);
        if (match && match[1]) {
          const json = JSON.parse(match[1]);
          
          // Поиск объекта offer в глубинном JSON
          const offer =
            json.offerData?.offer ||
            json.initialState?.offer ||
            findObjectWithKeys(json, ['bargainTerms', 'totalArea', 'floorNumber', 'building']);

          if (offer) {
            if (offer.bargainTerms?.priceRur) price = Number(offer.bargainTerms.priceRur);
            if (offer.totalArea) area = parseFloat(offer.totalArea);
            
            // Этаж и этажность из JSON
            if (offer.floorNumber) floor = Number(offer.floorNumber);
            if (offer.building?.floorsCount) totalFloors = Number(offer.building.floorsCount);
            if (!totalFloors && offer.floorsCount) totalFloors = Number(offer.floorsCount);

            if (offer.roomsCount) rooms = Number(offer.roomsCount);
            if (offer.geo?.address) {
              address = offer.geo.address.map((a: any) => a.fullName).join(', ');
            }
            if (offer.photos && offer.photos.length > 0) {
              photo = offer.photos[0].fullUrl || offer.photos[0].url;
            }

            // Статистика просмотров из JSON
            if (offer.stats) {
              if (offer.stats.totalViews) viewsTotal = Number(offer.stats.totalViews);
              if (offer.stats.dailyViews) viewsToday = Number(offer.stats.dailyViews);
            }
          }
        }
      } catch {}
    }
  }

  // 2. JSON-LD fallback
  if (!price || !area || !floor) {
    try {
      $('script[type="application/ld+json"]').each((_, el) => {
        const text = $(el).html();
        if (!text) return;
        try {
          const json = JSON.parse(text);
          if (json.offers?.price && !price) price = Number(json.offers.price);
          if (json.name && !address) address = json.name;
          if (json.image && !photo) photo = Array.isArray(json.image) ? json.image[0] : json.image;
          if (json.floorLevel && !floor) floor = Number(json.floorLevel);
          if (json.numberOfFloors && !totalFloors) totalFloors = Number(json.numberOfFloors);
        } catch {}
      });
    } catch {}
  }

  // 3. Селекторы DOM для цены и адреса
  if (!price) {
    const priceText =
      $('[data-name="PriceInfo"]').text() ||
      $('[data-testid="price-amount"]').text() ||
      $('.a10a3f92e9--price_value--').text();
    const cleanPrice = priceText.replace(/\D/g, '');
    if (cleanPrice) price = Number(cleanPrice);
  }

  if (!address) {
    address =
      $('[data-name="Geo"]').text().trim() ||
      $('[data-name="AddressContainer"]').text().trim() ||
      $('address').text().trim() ||
      $('h1').text().trim();
  }

  // 4. Специальный извлекатель этажа / этажности из фактоидов ЦИАН
  $('[data-name="ObjectSummaryInfoItem"], [data-name="ObjectFactoidsItem"], [data-name="Factoid"], div').each((_, el) => {
    const text = $(el).text().trim();
    if (!text) return;

    // Вариант 1: "12 из 24" или "12 из 24 этаж"
    const fMatch1 = text.match(/(\d+)\s*из\s*(\d+)/i);
    if (fMatch1 && (!floor || !totalFloors)) {
      floor = parseInt(fMatch1[1], 10);
      totalFloors = parseInt(fMatch1[2], 10);
    }

    // Вариант 2: "12 / 24 эт"
    const fMatch2 = text.match(/(\d+)\s*\/\s*(\d+)/i);
    if (fMatch2 && (!floor || !totalFloors) && /этаж/i.test(text)) {
      floor = parseInt(fMatch2[1], 10);
      totalFloors = parseInt(fMatch2[2], 10);
    }
  });

  // 5. Глобальный текстовый поиск по всему HTML для этажа, этажности, просмотров и комнатности
  const pageTitle = ($('title').text() + ' ' + $('h1').text()).trim();
  const fullText = (pageTitle + ' ' + $.text()).trim();

  if (!floor || !totalFloors) {
    const globalFloorMatch =
      fullText.match(/Этаж[:\s]*(\d+)\s*из\s*(\d+)/i) ||
      fullText.match(/(\d+)\s*эт[аж]*\s*из\s*(\d+)/i) ||
      fullText.match(/(\d+)\s*из\s*(\d+)\s*этаж/i) ||
      fullText.match(/(\d+)\s*\/\s*(\d+)\s*эт/i);

    if (globalFloorMatch) {
      if (!floor) floor = parseInt(globalFloorMatch[1], 10);
      if (!totalFloors) totalFloors = parseInt(globalFloorMatch[2], 10);
    }
  }

  // Извлечение просмотров из HTML
  if (!viewsTotal) {
    const viewsMatch =
      fullText.match(/([\d\s]+)\s*просмотр/i) ||
      fullText.match(/просмотров[:\s]*([\d\s]+)/i) ||
      $('[data-name="OfferStats"]').text().match(/([\d\s]+)/);

    if (viewsMatch && viewsMatch[1]) {
      const cleanViews = viewsMatch[1].replace(/\s/g, '');
      if (cleanViews && !isNaN(Number(cleanViews))) {
        viewsTotal = parseInt(cleanViews, 10);
      }
    }
  }

  if (!viewsToday) {
    const todayMatch = fullText.match(/\+?\s*(\d+)\s*за\s*сегодня/i) || fullText.match(/\+(\d+)\s*сегодня/i);
    if (todayMatch && todayMatch[1]) {
      viewsToday = parseInt(todayMatch[1], 10);
    }
  }

  if (!area) {
    const areaMatch = fullText.match(/Общая площадь[:\s]*([\d[.,]+)\s*м²/i) || fullText.match(/([\d[.,]+)\s*м²/i);
    if (areaMatch) area = parseFloat(areaMatch[1].replace(',', '.'));
  }

  // Количество комнат
  if (!rooms || rooms === 1) {
    if (/студия/i.test(fullText)) {
      rooms = 1;
    } else {
      const roomsMatch =
        fullText.match(/(\d+)\s*-\s*комн/i) ||
        fullText.match(/(\d+)\s*-\s*к(?:омн|атная|\.)?/i) ||
        fullText.match(/(\d+)\s*(?:комнатная|комнат|комн)/i) ||
        fullText.match(/Количество комнат[:\s]*(\d+)/i);

      if (roomsMatch && roomsMatch[1]) {
        rooms = parseInt(roomsMatch[1], 10);
      }
    }
  }

  // Ремонт
  if (/дизайнерский/i.test(fullText)) renovation = 'Дизайнерский';
  else if (/евро/i.test(fullText)) renovation = 'Евро';
  else if (/без ремонта/i.test(fullText)) renovation = 'Без ремонта';

  // Материал дома
  if (/монолит/i.test(fullText)) buildingMaterial = 'Монолит-кирпич';
  else if (/кирпич/i.test(fullText)) buildingMaterial = 'Кирпичный';
  else if (/панель/i.test(fullText)) buildingMaterial = 'Панельный';

  const pricePerSqm = area > 0 ? Math.round(price / area) : 0;

  return {
    address: address || 'г. Москва (Адрес из объявления ЦИАН)',
    price: price || 0,
    area: area || 0,
    pricePerSqm,
    floor: floor || 1,
    totalFloors: totalFloors || 1,
    rooms: rooms || 1,
    renovation,
    buildingMaterial,
    yearBuilt: yearBuilt || new Date().getFullYear(),
    photo: photo || 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&auto=format&fit=crop&q=80',
    viewsTotal: viewsTotal || 0,
    viewsToday: viewsToday || 0,
    source: 'cian',
  };
}

function findObjectWithKeys(obj: any, keys: string[]): any {
  if (!obj || typeof obj !== 'object') return null;
  for (const key of keys) {
    if (key in obj) return obj;
  }
  for (const k of Object.keys(obj)) {
    const res = findObjectWithKeys(obj[k], keys);
    if (res) return res;
  }
  return null;
}
