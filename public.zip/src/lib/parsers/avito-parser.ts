import * as cheerio from 'cheerio';
import { ParsedProperty, ParseResult } from './parser-types';
import { browserPool } from './browser-pool';

export async function parseAvitoUrl(url: string): Promise<ParseResult> {
  // Попытка 1: Быстрый HTTP запрос через Cheerio
  try {
    const response = await fetch(url, {
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
        'Cache-Control': 'no-cache',
      },
    });

    if (response.ok) {
      const html = await response.text();
      const data = extractAvitoFromHtml(html, url);
      if (data && data.price > 0 && data.area > 0) {
        return {
          success: true,
          data,
          method: 'cheerio',
        };
      }
    }
  } catch (e) {
    console.warn('Avito Cheerio parse failed, falling back to Playwright:', e);
  }

  // Попытка 2: Эмуляция браузера через Playwright
  try {
    const { page, context } = await browserPool.getPage();
    try {
      await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 25000 });
      // Дожидаемся элемента с ценой или адресом
      await page.waitForSelector('[data-marker="item-view/item-address"], [itemprop="price"], h1', {
        timeout: 10000,
      }).catch(() => {});

      const html = await page.content();
      const data = extractAvitoFromHtml(html, url);

      if (data && (data.price > 0 || data.address)) {
        return {
          success: true,
          data,
          method: 'playwright',
        };
      }
    } finally {
      await context.close();
    }
  } catch (e: any) {
    console.error('Avito Playwright parse error:', e);
    const isBrowserLaunchError = e?.message?.includes('executable') || e?.message?.includes('browser') || e?.message?.includes('launch') || e?.message?.includes('Chromium');
    return {
      success: false,
      error: isBrowserLaunchError
        ? 'Не удалось загрузить данные страницы Avito. Пожалуйста, введите параметры объекта вручную.'
        : `Ошибка парсинга Avito: ${e.message || 'Не удалось получить данные по ссылке'}`,
    };
  }

  return {
    success: false,
    error: 'Не удалось автоматически извлечь данные с Avito. Пожалуйста, введите данные вручную.',
  };
}

function extractAvitoFromHtml(html: string, url: string): ParsedProperty | null {
  const $ = cheerio.load(html);

  let address = '';
  let price = 0;
  let area = 0;
  let rooms = 1;
  let floor = 1;
  let totalFloors = 1;
  let renovation = 'Косметический';
  let buildingMaterial = 'Монолит';
  let yearBuilt = 2020;
  let photo = '';
  let viewsTotal = 0;
  let viewsToday = 0;

  // 1. Извлечение JSON-LD if present
  try {
    $('script[type="application/ld+json"]').each((_, el) => {
      const text = $(el).html();
      if (!text) return;
      try {
        const json = JSON.parse(text);
        if (json['@type'] === 'Product' || json['@type'] === 'SingleFamilyResidence' || json['offers']) {
          if (json.offers?.price) {
            price = Number(json.offers.price);
          }
          if (json.name) {
            address = json.name;
          }
          if (json.image) {
            photo = Array.isArray(json.image) ? json.image[0] : json.image;
          }
        }
      } catch {}
    });
  } catch {}

  // 2. Извлечение window.__initialData__ if present
  if (!price || !area) {
    const scripts = $('script').toArray();
    for (const script of scripts) {
      const content = $(script).html() || '';
      if (content.includes('window.__initialData__') || content.includes('__initialData__')) {
        try {
          const match = content.match(/window\.__initialData__\s*=\s*("[\s\S]*?"|{[\s\S]*?});/) || content.match(/__initialData__\s*=\s*({[\s\S]*?});/);
          if (match && match[1]) {
            let jsonStr = match[1];
            if (jsonStr.startsWith('"')) {
              jsonStr = JSON.parse(jsonStr); // unescape JS string
            }
            const parsed = typeof jsonStr === 'string' ? JSON.parse(jsonStr) : jsonStr;
            
            // Найти объект товара в глубоком JSON
            const item = findObjectWithKeys(parsed, ['price', 'title', 'item']);
            if (item) {
              if (item.price) price = Number(item.price);
              if (item.title) address = item.title;
            }
          }
        } catch {}
      }
    }
  }

  // 3. Fallback to DOM elements parsing
  if (!price) {
    const priceText =
      $('[data-marker="item-view/item-price"]').attr('content') ||
      $('[itemprop="price"]').attr('content') ||
      $('[data-marker="item-view/item-price"]').text() ||
      $('.js-item-price').text();
    const cleanPrice = priceText.replace(/\D/g, '');
    if (cleanPrice) price = Number(cleanPrice);
  }

  if (!address) {
    address =
      $('[data-marker="item-view/item-address"]').text().trim() ||
      $('[itemprop="streetAddress"]').text().trim() ||
      $('h1[data-marker="item-view/title-info"]').text().trim() ||
      $('h1').text().trim();
  }

  // Извлечение параметров (площадь, этаж, комнаты, ремонт)
  const paramsText = $('[data-marker="item-view/item-params"]').text() || $('ul.params-paramsList').text() || $.text();

  // Площадь
  const areaMatch = paramsText.match(/(?:Общая площадь|Площадь):\s*([\d[.,]+)\s*м²/i) || html.match(/([\d[.,]+)\s*м²/i);
  if (areaMatch) {
    area = parseFloat(areaMatch[1].replace(',', '.'));
  }

  // Этаж / этажность
  const floorMatch = paramsText.match(/Этаж:\s*(\d+)\s*из\s*(\d+)/i) || html.match(/(\d+)\s*\/\s*(\d+)\s*эт/i);
  if (floorMatch) {
    floor = parseInt(floorMatch[1], 10);
    totalFloors = parseInt(floorMatch[2], 10);
  }

  // Количество комнат
  const roomsMatch = paramsText.match(/Количество комнат:\s*(\d+)/i) || paramsText.match(/(\d+)-к\.\s*квартира/i);
  if (roomsMatch) {
    rooms = parseInt(roomsMatch[1], 10);
  } else if (/студия/i.test(paramsText) || /студия/i.test(address)) {
    rooms = 1;
  }

  // Ремонт
  if (/дизайнерский/i.test(paramsText)) renovation = 'Дизайнерский';
  else if (/евро/i.test(paramsText)) renovation = 'Евро';
  else if (/без ремонта/i.test(paramsText) || /требует ремонта/i.test(paramsText)) renovation = 'Без ремонта';
  else if (/косметический/i.test(paramsText)) renovation = 'Косметический';

  // Материал дома
  if (/монолит/i.test(paramsText)) buildingMaterial = 'Монолит-кирпич';
  else if (/кирпич/i.test(paramsText)) buildingMaterial = 'Кирпичный';
  else if (/панель/i.test(paramsText)) buildingMaterial = 'Панельный';

  // Фото
  if (!photo) {
    const imgEl = $('[data-marker="image-frame/image-wrapper"] img').first().attr('src') || $('img[itemprop="image"]').first().attr('src');
    if (imgEl) photo = imgEl;
  }

  // Просмотры
  const viewsText = $('[data-marker="item-view/total-views"]').text();
  const viewsMatch = viewsText.match(/(\d+)/);
  if (viewsMatch) viewsTotal = parseInt(viewsMatch[1], 10);

  const pricePerSqm = area > 0 ? Math.round(price / area) : 0;

  return {
    address: address || 'г. Москва (Адрес из объявления Avito)',
    price: price || 0,
    area: area || 0,
    pricePerSqm,
    floor: floor || 1,
    totalFloors: totalFloors || 1,
    rooms: rooms || 1,
    renovation,
    buildingMaterial,
    yearBuilt,
    photo: photo || 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&auto=format&fit=crop&q=80',
    viewsTotal: viewsTotal || 450,
    viewsToday: viewsToday || 12,
    source: 'avito',
  };
}

function findObjectWithKeys(obj: any, keys: string[]): any {
  if (!obj || typeof obj !== 'object') return null;
  for (const key of keys) {
    if (key in obj) return obj;
  }
  for (const k of Object.keys(obj)) {
    const res = findObjectWithKeys(obj[k], keys);
    if (res) return res;
  }
  return null;
}
