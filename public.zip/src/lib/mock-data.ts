import { Property, Report, UserProfile, DashboardStats } from '@/types';

export const INITIAL_USER: UserProfile = {
  name: 'Пользователь СМА',
  phone: '',
  email: '',
  company: 'Агентство Недвижимости',
  position: 'Аналитик СМА',
  photo: '',
  companyLogo: '',
};

export const INITIAL_STATS: DashboardStats = {
  totalReports: 0,
  totalProperties: 0,
  averagePrice: 0,
  lastAnalysisDate: '-',
};

export const EMPTY_TARGET_PROPERTY: Property = {
  id: 'target-new',
  url: '',
  photo: '',
  address: '',
  price: 0,
  area: 0,
  pricePerSqm: 0,
  rooms: 1,
  floor: 1,
  totalFloors: 1,
  buildingMaterial: 'Монолит',
  buildingType: 'Вторичка',
  yearBuilt: new Date().getFullYear(),
  renovation: 'Косметический',
  source: 'avito',
};

export const DEMO_TARGET_PROPERTY: Property = EMPTY_TARGET_PROPERTY;

export const INITIAL_COMPETITORS: Property[] = [];

export const INITIAL_REPORTS: Report[] = [];

