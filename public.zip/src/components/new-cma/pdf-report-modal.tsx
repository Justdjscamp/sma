'use client';

import { Property, CmaAdjustments, UserProfile } from '@/types';
import { formatCurrency, formatNumber, formatDate } from '@/lib/formatters';
import { X, Printer, Download, Building2, ExternalLink } from 'lucide-react';
import { useRef } from 'react';

interface PdfReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetProperty: Property;
  competitors: Property[];
  adjustments: CmaAdjustments;
  user: UserProfile;
  reportId?: string;
}

export function PdfReportModal({
  isOpen,
  onClose,
  targetProperty,
  competitors,
  adjustments,
  user,
  reportId,
}: PdfReportModalProps) {
  const reportRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  // Active competitors calculations
  const activeCompetitors = competitors.filter((c) => c.price > 0);
  const prices = activeCompetitors.map((c) => c.price);
  const priceSqms = activeCompetitors.map((c) => c.pricePerSqm);
  const count = activeCompetitors.length;

  const avgPriceSqm = count > 0 ? Math.round(priceSqms.reduce((a, b) => a + b, 0) / count) : targetProperty.pricePerSqm;
  const sortedBySqm = [...activeCompetitors].sort((a, b) => a.pricePerSqm - b.pricePerSqm);
  
  // TOP 3 cheapest & expensive per sqm
  const topCheapestSqms = sortedBySqm.slice(0, 3);
  const topExpensiveSqms = sortedBySqm.slice(-3).reverse();

  const cheapestAvgSqm = topCheapestSqms.length > 0
    ? Math.round(topCheapestSqms.reduce((a, b) => a + b.pricePerSqm, 0) / topCheapestSqms.length)
    : targetProperty.pricePerSqm;

  const expensiveAvgSqm = topExpensiveSqms.length > 0
    ? Math.round(topExpensiveSqms.reduce((a, b) => a + b.pricePerSqm, 0) / topExpensiveSqms.length)
    : targetProperty.pricePerSqm;

  // Total adjustment percent
  const totalAdjPercent =
    adjustments.floorAdjustment +
    adjustments.renovationAdjustment +
    adjustments.balconyAdjustment +
    adjustments.demandAdjustment +
    adjustments.legalAdjustment;

  // Base Prices before adjustments
  const basePrice = Math.round(targetProperty.area * avgPriceSqm);
  const baseLow = Math.round(basePrice * 0.93);
  const baseHigh = Math.round(basePrice * 1.05);

  // Adjusted Prices
  const adjustedPrice = Math.round(basePrice * (1 + totalAdjPercent / 100));
  const adjustedLow = Math.round(baseLow * (1 + totalAdjPercent / 100));
  const adjustedHigh = Math.round(baseHigh * (1 + totalAdjPercent / 100));

  // Deviations %
  const devAvg = avgPriceSqm > 0 ? (((targetProperty.pricePerSqm - avgPriceSqm) / avgPriceSqm) * 100).toFixed(1) : '0';
  const devLow = cheapestAvgSqm > 0 ? (((targetProperty.pricePerSqm - cheapestAvgSqm) / cheapestAvgSqm) * 100).toFixed(1) : '0';
  const devHigh = expensiveAvgSqm > 0 ? (((targetProperty.pricePerSqm - expensiveAvgSqm) / expensiveAvgSqm) * 100).toFixed(1) : '0';

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      {/* Container */}
      <div className="bg-white w-full max-w-5xl rounded-2xl shadow-2xl overflow-hidden my-8 border border-slate-200">
        {/* Top Modal Controls */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between no-print">
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-blue-400" />
            <span className="font-bold text-sm">Предпросмотр оригинального отчёта СМА (Образец)</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs px-4 py-2 rounded-xl transition-all shadow-md"
            >
              <Printer className="w-4 h-4" /> Распечатать / Сохранить в PDF
            </button>

            <button
              onClick={onClose}
              className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* PRINTABLE ANALYTICS REPORT BODY */}
        <div ref={reportRef} className="p-8 space-y-6 bg-white text-slate-900 text-xs print:p-0">
          
          {/* Agency Branding & Document Header */}
          <div className="flex items-center justify-between border-b-2 border-slate-900 pb-4">
            <div className="space-y-1">
              <div className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
                <Building2 className="w-6 h-6 text-blue-600 inline" />
                <span>{user.company || 'Вектор Недвижимость'}</span>
              </div>
              <p className="text-[11px] text-slate-500 font-semibold">
                Сравнительный Маркетинговый Анализ (СМА) стоимости недвижимости
              </p>
            </div>

            <div className="text-right text-[11px] text-slate-600 space-y-0.5 font-semibold">
              <div>Аналитик: <strong className="text-slate-900">{user.name}</strong></div>
              <div>Тел: <strong className="text-slate-900">{user.phone}</strong></div>
              <div>Email: <strong className="text-slate-900">{user.email}</strong></div>
            </div>
          </div>

          {/* Header Metadata Links Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] font-semibold border-b border-slate-300 pb-3 bg-slate-50 p-2.5 rounded-lg border border-slate-200">
            <div>
              <span className="text-slate-400">Заявка:</span>{' '}
              <span className="font-bold text-blue-600">№ {reportId || 'cma-604488'}</span>
            </div>
            <div>
              <span className="text-slate-400">Источник:</span>{' '}
              <span className="font-bold text-slate-800">{targetProperty.source === 'avito' ? 'Авито' : 'ЦИАН'}</span>
            </div>
            <div>
              <span className="text-slate-400">Объект:</span>{' '}
              <span className="font-bold text-blue-600 truncate">{targetProperty.address}</span>
            </div>
            <div className="text-right">
              <span className="text-slate-400">Дата отчета:</span>{' '}
              <span className="font-bold text-slate-800">{new Date().toISOString().split('T')[0]}</span>
            </div>
          </div>

          {/* Section 1 & 2: Top Pricing Tables Grid */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            
            {/* Left: Owner Price Box (Soft Pink Accent) */}
            <div className="md:col-span-5 bg-pink-100/70 border-2 border-slate-900 rounded-xl p-4 space-y-3">
              <h3 className="font-black text-sm text-slate-900 border-b border-slate-900 pb-2 uppercase tracking-wide">
                Цена собственника
              </h3>

              <div className="space-y-2 font-bold text-xs">
                <div className="flex justify-between items-center py-1 border-b border-pink-200">
                  <span className="text-slate-700">Цена собственника:</span>
                  <span className="text-sm font-extrabold">{formatCurrency(targetProperty.price)}</span>
                </div>
                <div className="flex justify-between items-center py-1 border-b border-pink-200">
                  <span className="text-slate-700">Площадь:</span>
                  <span>{targetProperty.area} м²</span>
                </div>
                <div className="flex justify-between items-center py-1 bg-emerald-300 px-2 rounded-md font-black text-slate-900">
                  <span>Цена за м²:</span>
                  <span>{formatNumber(targetProperty.pricePerSqm)} ₽</span>
                </div>
              </div>
            </div>

            {/* Right: Calculated Base & Adjusted Prices (Soft Yellow Accent) */}
            <div className="md:col-span-7 space-y-3">
              {/* Unadjusted Summary Table */}
              <div className="border-2 border-slate-900 rounded-xl overflow-hidden">
                <div className="bg-purple-100 border-b-2 border-slate-900 px-3 py-1.5 font-bold flex justify-between">
                  <span>Итоговая стоимость (базовая):</span>
                  <span>За м²</span>
                </div>
                <table className="w-full text-xs text-center border-collapse">
                  <tbody>
                    <tr className="border-b border-slate-300">
                      <td className="p-1.5 font-bold bg-slate-50 w-24 text-left">Среднее</td>
                      <td className="p-1.5 font-extrabold">{formatCurrency(basePrice)}</td>
                      <td className="p-1.5 font-bold text-blue-600">{formatNumber(avgPriceSqm)} ₽</td>
                    </tr>
                    <tr className="border-b border-slate-300">
                      <td className="p-1.5 font-bold bg-slate-50 text-left">Низ</td>
                      <td className="p-1.5 font-bold text-slate-800">{formatCurrency(baseLow)}</td>
                      <td className="p-1.5 font-medium text-slate-600">{formatNumber(Math.round(baseLow / targetProperty.area))} ₽</td>
                    </tr>
                    <tr>
                      <td className="p-1.5 font-bold bg-slate-50 text-left">Верх</td>
                      <td className="p-1.5 font-bold text-slate-800">{formatCurrency(baseHigh)}</td>
                      <td className="p-1.5 font-medium text-slate-600">{formatNumber(Math.round(baseHigh / targetProperty.area))} ₽</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Adjusted Summary Table (Yellow Highlighted) */}
              <div className="border-2 border-slate-900 rounded-xl overflow-hidden bg-amber-100">
                <div className="bg-amber-300 border-b-2 border-slate-900 px-3 py-1.5 font-black flex justify-between text-slate-900">
                  <span>Итоговая стоимость с учетом корректировки</span>
                  <span>За м²</span>
                </div>
                <div className="grid grid-cols-12">
                  <table className="col-span-8 w-full text-xs text-center border-r-2 border-slate-900">
                    <tbody>
                      <tr className="border-b border-slate-300">
                        <td className="p-1.5 font-bold text-left bg-amber-200/60 w-20">Среднее</td>
                        <td className="p-1.5 font-extrabold">{formatCurrency(adjustedPrice)}</td>
                        <td className="p-1.5 font-bold text-blue-700">{formatNumber(Math.round(adjustedPrice / targetProperty.area))} ₽</td>
                      </tr>
                      <tr className="border-b border-slate-300">
                        <td className="p-1.5 font-bold text-left bg-amber-200/60">Низ</td>
                        <td className="p-1.5 font-semibold">{formatCurrency(adjustedLow)}</td>
                        <td className="p-1.5 text-slate-700">{formatNumber(Math.round(adjustedLow / targetProperty.area))} ₽</td>
                      </tr>
                      <tr>
                        <td className="p-1.5 font-bold text-left bg-amber-200/60">Верх</td>
                        <td className="p-1.5 font-semibold">{formatCurrency(adjustedHigh)}</td>
                        <td className="p-1.5 text-slate-700">{formatNumber(Math.round(adjustedHigh / targetProperty.area))} ₽</td>
                      </tr>
                    </tbody>
                  </table>

                  {/* Big Adjustment % Box */}
                  <div className="col-span-4 flex flex-col items-center justify-center p-2 text-center font-black">
                    <span className="text-[10px] text-slate-600 uppercase font-bold">Корректировка:</span>
                    <span className="text-2xl font-black text-slate-900 mt-1">
                      {totalAdjPercent > 0 ? `+${totalAdjPercent},0%` : `${totalAdjPercent},0%`}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Section 3: Market Data & Deviation Grid */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            
            {/* Market Cheap/Expensive List */}
            <div className="md:col-span-5 border-2 border-slate-900 rounded-xl overflow-hidden text-xs">
              <div className="bg-purple-200 border-b-2 border-slate-900 p-2 font-black">
                Данные рынка (₽/м²)
              </div>
              <div className="p-3 space-y-3">
                <div>
                  <span className="font-bold text-[11px] text-slate-600 block mb-1">3 самых дешевых квартиры по м²:</span>
                  {topCheapestSqms.map((item, idx) => (
                    <div key={idx} className="flex justify-between py-0.5 border-b border-slate-100">
                      <span className="truncate max-w-[170px] text-[11px]">{item.address}</span>
                      <span className="font-bold text-emerald-700">{formatNumber(item.pricePerSqm)} ₽</span>
                    </div>
                  ))}
                </div>

                <div>
                  <span className="font-bold text-[11px] text-slate-600 block mb-1">3 самых дорогих квартиры по м²:</span>
                  {topExpensiveSqms.map((item, idx) => (
                    <div key={idx} className="flex justify-between py-0.5 border-b border-slate-100">
                      <span className="truncate max-w-[170px] text-[11px]">{item.address}</span>
                      <span className="font-bold text-rose-700">{formatNumber(item.pricePerSqm)} ₽</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Deviations & Calculations */}
            <div className="md:col-span-7 border-2 border-slate-900 rounded-xl overflow-hidden text-xs">
              <div className="bg-purple-200 border-b-2 border-slate-900 p-2 font-black">
                % отклонения от рыночной цены за м² & Просчёт
              </div>
              <div className="p-3 grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <span className="font-bold text-slate-500 text-[11px] block">Отклонения:</span>
                  <div className="flex justify-between py-1 border-b border-slate-100 font-semibold">
                    <span>Среднее:</span>
                    <span className="font-bold text-slate-900">{devAvg}%</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-100 font-semibold">
                    <span>Низ:</span>
                    <span className="font-bold text-emerald-700">{devLow}%</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-100 font-semibold">
                    <span>Верх:</span>
                    <span className="font-bold text-rose-700">{devHigh}%</span>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <span className="font-bold text-slate-500 text-[11px] block">Просчет стоимости объекта (за м²):</span>
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span>Среднее по дешевым:</span>
                    <span className="font-bold">{formatNumber(cheapestAvgSqm)} ₽</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-100">
                    <span>Среднее по дорогим:</span>
                    <span className="font-bold">{formatNumber(expensiveAvgSqm)} ₽</span>
                  </div>
                  <div className="flex justify-between py-1 bg-purple-50 p-1 rounded font-bold text-purple-900">
                    <span>Общее среднее:</span>
                    <span>{formatNumber(avgPriceSqm)} ₽</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Section 4: Adjustments Criteria Table (Yellow Header) */}
          <div className="border-2 border-slate-900 rounded-xl overflow-hidden">
            <div className="bg-amber-300 border-b-2 border-slate-900 p-2 text-center font-black text-slate-900 uppercase tracking-wide">
              Критерии корректировок
            </div>
            
            <table className="w-full text-center text-xs border-collapse">
              <thead>
                <tr className="bg-amber-100 font-bold border-b border-slate-900">
                  <th className="p-2 border-r border-slate-900 w-1/6">Этаж</th>
                  <th className="p-2 border-r border-slate-900 w-1/6">Ремонт</th>
                  <th className="p-2 border-r border-slate-900 w-1/6">Конкуренты в локации</th>
                  <th className="p-2 border-r border-slate-900 w-1/6">Балкон</th>
                  <th className="p-2 border-r border-slate-900 w-1/6">Спрос по локации</th>
                  <th className="p-2 w-1/6">Документы</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                <tr>
                  <td className="p-2 border-r border-slate-200 align-top">
                    <div className="font-bold">1 этаж (−10%)</div>
                    <div className="text-[11px] text-slate-500">2–4 этаж (−3%)</div>
                    <div className="text-[11px] text-slate-500">Высокий (+2%)</div>
                  </td>

                  <td className="p-2 border-r border-slate-200 align-top">
                    <div className="text-[11px] text-slate-500">«Убитая» (−10%)</div>
                    <div className="text-[11px] text-slate-500">Хуже (−5%)</div>
                    <div className="font-bold text-emerald-700">Лучше (+5%)</div>
                    <div className="text-[11px] text-slate-500">Флип (+20%)</div>
                  </td>

                  <td className="p-2 border-r border-slate-200 align-top">
                    <div className="text-[11px] text-slate-500">100 объектов (−10%)</div>
                    <div className="font-bold">5 объектов (+1%)</div>
                    <div className="text-[11px] text-slate-500">1-2 объекта (+3%)</div>
                  </td>

                  <td className="p-2 border-r border-slate-200 align-top">
                    <div className="text-[11px] text-slate-500">Отсутствует (−6%)</div>
                    <div className="font-bold">Есть в доме (0%)</div>
                  </td>

                  <td className="p-2 border-r border-slate-200 align-top">
                    <div className="font-bold">Сбалансирован (0%)</div>
                    <div className="text-[11px] text-slate-500">Высокий (+3%)</div>
                  </td>

                  <td className="p-2 align-top">
                    <div className="text-[11px] text-slate-500">Опека/доли (−3%)</div>
                    <div className="text-[11px] text-slate-500">Обременение (−3%)</div>
                    <div className="font-bold">Чистая (0%)</div>
                  </td>
                </tr>

                {/* Summary row */}
                <tr className="bg-amber-100/60 font-black border-t-2 border-slate-900">
                  <td className="p-2 border-r border-slate-900">{adjustments.floorAdjustment > 0 ? `+${adjustments.floorAdjustment}%` : `${adjustments.floorAdjustment}%`}</td>
                  <td className="p-2 border-r border-slate-900">{adjustments.renovationAdjustment > 0 ? `+${adjustments.renovationAdjustment}%` : `${adjustments.renovationAdjustment}%`}</td>
                  <td className="p-2 border-r border-slate-900">{adjustments.demandAdjustment > 0 ? `+${adjustments.demandAdjustment}%` : `${adjustments.demandAdjustment}%`}</td>
                  <td className="p-2 border-r border-slate-900">{adjustments.balconyAdjustment > 0 ? `+${adjustments.balconyAdjustment}%` : `${adjustments.balconyAdjustment}%`}</td>
                  <td className="p-2 border-r border-slate-900">0,00%</td>
                  <td className="p-2">{adjustments.legalAdjustment > 0 ? `+${adjustments.legalAdjustment}%` : `${adjustments.legalAdjustment}%`}</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Section 5: Competitor Properties Analytical Table */}
          <div className="border-2 border-slate-900 rounded-xl overflow-hidden">
            <div className="bg-slate-900 text-white p-2 font-black uppercase text-center tracking-wide">
              Список объектов-конкурентов для аналитики ({count} объектов)
            </div>

            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-100 font-bold border-b border-slate-900 text-[11px]">
                  <th className="p-2">#</th>
                  <th className="p-2">Ссылка / Адрес</th>
                  <th className="p-2">Стоимость</th>
                  <th className="p-2">м²</th>
                  <th className="p-2">руб за метр</th>
                  <th className="p-2">Ремонт</th>
                  <th className="p-2">Этаж</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {/* Target Property highlighted first */}
                <tr className="bg-pink-50 font-bold border-b-2 border-pink-200">
                  <td className="p-2 text-pink-700">Цель</td>
                  <td className="p-2 text-slate-900">{targetProperty.address}</td>
                  <td className="p-2">{formatCurrency(targetProperty.price)}</td>
                  <td className="p-2">{targetProperty.area}</td>
                  <td className="p-2 text-blue-700">{formatNumber(targetProperty.pricePerSqm)} ₽</td>
                  <td className="p-2">{targetProperty.renovation || 'Дизайнерский'}</td>
                  <td className="p-2">{targetProperty.floor}/{targetProperty.totalFloors}</td>
                </tr>

                {activeCompetitors.map((comp, idx) => (
                  <tr key={comp.id || idx} className="hover:bg-slate-50">
                    <td className="p-2 font-bold text-slate-400">{idx + 1}</td>
                    <td className="p-2 truncate max-w-xs font-semibold text-slate-800">{comp.address}</td>
                    <td className="p-2 font-bold text-slate-900">{formatCurrency(comp.price)}</td>
                    <td className="p-2">{comp.area}</td>
                    <td className="p-2 font-bold text-blue-600">{formatNumber(comp.pricePerSqm)} ₽</td>
                    <td className="p-2">{comp.renovation || 'Косметический'}</td>
                    <td className="p-2">{comp.floor}/{comp.totalFloors}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Footer signature bar */}
          <div className="pt-4 border-t border-slate-300 flex items-center justify-between text-[11px] text-slate-500 font-medium">
            <div>Аналитический модуль <strong>CMA Expert</strong></div>
            <div>Подпись риелтора: _______________________</div>
          </div>
        </div>
      </div>
    </div>
  );
}
