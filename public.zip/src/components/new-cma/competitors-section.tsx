'use client';

import { Property } from '@/types';
import { CompetitorCard } from './competitor-card';
import { Plus, Users, AlertCircle } from 'lucide-react';

interface CompetitorsSectionProps {
  competitors: Property[];
  onAddCompetitor: () => void;
  onUpdateCompetitor: (index: number, updated: Property) => void;
  onRemoveCompetitor: (index: number) => void;
}

export function CompetitorsSection({
  competitors,
  onAddCompetitor,
  onUpdateCompetitor,
  onRemoveCompetitor,
}: CompetitorsSectionProps) {
  const isMaxReached = competitors.length >= 20;

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-blue-600" />
            <h3 className="font-bold text-slate-900 text-lg">Конкуренты объекта</h3>
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200">
              {competitors.length} / 20
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Добавьте от 3 до 20 аналогичных объектов для точного сравнительного анализа
          </p>
        </div>

        <button
          onClick={onAddCompetitor}
          disabled={isMaxReached}
          className="inline-flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 disabled:text-slate-400 text-white font-medium text-sm px-4 py-2.5 rounded-xl shadow-sm shadow-blue-500/20 active:scale-[0.98] transition-all duration-150 shrink-0"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          Добавить конкурента
        </button>
      </div>

      {competitors.length === 0 ? (
        <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-12 text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto">
            <Users className="w-6 h-6" />
          </div>
          <h4 className="font-bold text-slate-800 text-base">Список конкурентов пуст</h4>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Нажмите кнопку «Добавить конкурента» сверху и вставьте ссылку с Avito или ЦИАН.
          </p>
          <button
            onClick={onAddCompetitor}
            className="inline-flex items-center gap-2 text-xs font-semibold text-blue-600 hover:text-blue-700 bg-blue-50 px-4 py-2 rounded-xl"
          >
            <Plus className="w-4 h-4" /> Добавить первого конкурента
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {competitors.map((competitor, index) => (
            <CompetitorCard
              key={competitor.id || index}
              index={index}
              competitor={competitor}
              onUpdate={(updated) => onUpdateCompetitor(index, updated)}
              onRemove={() => onRemoveCompetitor(index)}
            />
          ))}
        </div>
      )}
    </div>
  );
}
