# 🌐 Пошаговое руководство по деплою CMA Expert на VPS (hosting.com.tr)

Руководство по развертыванию проекта на VPS сервере под управлением **Ubuntu 22.04 / 24.04 LTS** или **Debian 12**.

---

## 🛠️ Предварительные требования

1. **Доступ к VPS**: IP-адрес сервера, root-пароль или SSH-ключ.
2. **Доменное имя**: Привязано (A-запись) к IP-адресу сервера (например, `cma.yourdomain.com`).

---

## 📋 Шаг 1. Первоначальная настройка сервера (SSH)

Подключитесь к вашему VPS по SSH:
```bash
ssh root@<IP_ВАШЕГО_СЕРВЕРА>
```

Обновите пакеты операционной системы:
```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y curl git build-essential nginx certbot python3-certbot-nginx
```

---

## 🟢 Шаг 2. Установка Node.js 20 LTS и PM2

Установите версию Node.js 20+:
```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Проверка версий
node -v
npm -v
```

Установите менеджер процессов **PM2**:
```bash
sudo npm install -g pm2
```

---

## 📁 Шаг 3. Загрузка проекта на сервер

Создайте директорию для сайта:
```bash
sudo mkdir -p /var/www/cma-expert
sudo chown -R $USER:$USER /var/www/cma-expert
cd /var/www/cma-expert
```

Скопируйте файлы проекта через Git или SCP:
```bash
# Пример при использовании Git:
git clone <URL_ВАШЕГО_РЕПОЗИТОРИЯ> .

# Или загрузите папку проекта через FileZilla / SCP
```

---

## 📦 Шаг 4. Установка зависимостей и системных библиотек Playwright

Установите npm-пакеты проекта:
```bash
npm install
```

Установите бинарник Chromium для Playwright:
```bash
npx playwright install chromium
```

Установите **системные библиотеки Linux**, необходимые для работы headless Chromium:
```bash
npx playwright install-deps
```

---

## ⚙️ Шаг 5. Сборка проекта и запуск через PM2

Создайте `.env` файл на основе образца:
```bash
cp .env.example .env
```

Соберите продакшен-билд Next.js:
```bash
npm run build
```

Запустите сервис через PM2:
```bash
pm2 start ecosystem.config.js
```

Настройте автозапуск PM2 при перезагрузке сервера:
```bash
pm2 save
pm2 startup
```
*(Скопируйте и выполните команду, которую предложит PM2)*.

---

## 🔒 Шаг 6. Настройка Nginx и бесплатного SSL-сертификата (HTTPS)

Создайте конфигурационный файл Nginx:
```bash
sudo nano /etc/nginx/sites-available/cma-expert
```

Вставьте следующую конфигурацию (замените `cma.yourdomain.com` на ваш домен):
```nginx
server {
    listen 80;
    server_name cma.yourdomain.com;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Увеличенный таймаут для работы Playwright
        proxy_read_timeout 60s;
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
    }
}
```

Активируйте конфигурацию и перезапустите Nginx:
```bash
sudo ln -s /etc/nginx/sites-available/cma-expert /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

Выпустите бесплатный **SSL-сертификат Let's Encrypt**:
```bash
sudo certbot --nginx -d cma.yourdomain.com
```

---

## 🎉 Шаг 7. Готово!

Ваш сервис **CMA Expert** теперь доступен по безопасному адресу:
`https://cma.yourdomain.com`

### Полезные команды для обслуживания сервера:
- Просмотр статуса сервиса: `pm2 status`
- Просмотр логов парсера в реальном времени: `pm2 logs cma-expert`
- Перезапуск сайта: `pm2 restart cma-expert`
